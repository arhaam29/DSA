
GROUP MEMBERS:
1. ARHAAM KHAN
2. ALYSSA LEAN YOUNGE
3. NEGAR KHALILAZAR

$$Random Data$$

![1](https://user-images.githubusercontent.com/97711825/226481165-4482724d-8a55-4678-b5b5-51569425b449.png)

**Conclusion: for random Data the standard insersertion is slower than modified one when size>=16.**

** *************** **

$$Sorted Data$$


![2](https://user-images.githubusercontent.com/97711825/226481776-d0a8f5cb-1bad-4469-93bf-519be355f9f1.png)

**Conclusion for sorted data both have the same speed**

** ************** **

$$Reversed Data$$

![3](https://user-images.githubusercontent.com/97711825/226482265-96389964-1753-4010-bcf0-2cad02b06a04.png)


**Conclusion: for reversed Data the standard insersertion is slower than modified one when size>=64.**

** *************** **

$$Organ Pipe Data$$


![4](https://user-images.githubusercontent.com/97711825/226482380-cdf1e0e7-42ab-47a1-b14b-4e2fb53cb844.png)


**Conclusion: for Organ Pipe Data the standard insersertion is slower than modified one when size>=64.**

** *************** **

$$Rotated Data$$

![5](https://user-images.githubusercontent.com/97711825/226482042-22289796-8510-49ca-8d39-825e4dcf95aa.png)


**Conclusion: for rotated Data the standard and modified have the same speed**

** *************** **
