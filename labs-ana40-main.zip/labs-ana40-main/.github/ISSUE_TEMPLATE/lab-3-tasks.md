---
name: Lab 3 Tasks
about: tasks related to lab 3
title: 'Lab 3 Tasks'
labels: ''
assignees: ''

---

Task list for lab:

- [ ] walk through the tester for lab3 and come up with the correct output based on the main
- [ ] complete and test the functions for Doubly linked list, use output from walkthrough to guide your debugging
- [ ] complete and test the functions for Sentinel list  use output from walkthrough to guide your debugging
- [ ] submit and commit pull request
