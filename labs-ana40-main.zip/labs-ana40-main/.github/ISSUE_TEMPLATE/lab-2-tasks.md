---
name: Lab 2 Tasks
about: tasks related to lab 2
title: 'Lab 2 Tasks'
labels: ''
assignees: ''

---

Task list for lab:

- [ ] filled in name/student number in comment
- [ ] write factorial function recursively
- [ ] write power function recursively
- [ ] write fibonacci function recursively
- [ ] analyze factorial function
- [ ] analyze power function
- [ ] answer the questions about the recursive fibonacii function from the lab
- [ ] submit and commit pull request
