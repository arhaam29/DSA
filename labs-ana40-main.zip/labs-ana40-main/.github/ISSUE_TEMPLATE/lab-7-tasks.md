---
name: Lab 7 Tasks
about: tasks related to lab 7
title: 'Lab 7 Tasks'
labels: ''
assignees: ''

---

- [ ] write the remove() function
- [ ] write the depth() function
- [ ] write the copy constructor
- [ ] submit and commit a pull request
