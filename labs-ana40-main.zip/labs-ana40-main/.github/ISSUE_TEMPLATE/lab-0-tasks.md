---
name: Lab 0 Tasks
about: tasks related to lab 0
title: 'Lab 0 Tasks'
labels: ''
assignees: ''

---


Task list for lab:

- [ ] create task list for lab 0 in your issue tracker (check off task as you complete them)
- [ ] spin up a codespace for your lab
- [ ] create a code space and write the C/C++ based factorial function in it
- [ ] compile and run the code
	- [ ] add commit and push your file from code space into your repo
- [ ] verify that your factorial function passes testing in actions tab
- [ ] create a the LaTex expression for those listed in lab
- [ ] create a simple chart and properly link it into your lab0.md file.  Chart should be visible without requiring any clicking of links
- [ ] add a post about yourself in the course discussion boards
- [ ] comment on another post or two in the thread
- [ ] answer reflections