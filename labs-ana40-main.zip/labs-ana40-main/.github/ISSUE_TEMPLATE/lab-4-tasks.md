---
name: Lab 4 Tasks
about: tasks related to lab 4
title: 'Lab 4 Tasks'
labels: ''
assignees: ''

---

Task list for lab:

- [ ] copy the code for push_front() and your destructor from lab 3 to lab4
- [ ] implement interators and const_iterators
- [ ] test and debug
- [ ] submit and commit pull request
