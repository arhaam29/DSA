---
name: Lab 6 Tasks
about: tasks related to lab 6
title: 'Lab 6 Tasks'
labels: ''
assignees: ''

---

Task list for lab:

- [ ] watch/rewatch the video
- [ ] implement one improvement to quicksort
- [ ] test your function
- [ ] experiment, gather data and graph
- [ ] write a discussion on your results
- [ ] submit and commit a pull request
