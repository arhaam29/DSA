---
name: Lab 1 Tasks
about: tasks related to lab 1
title: 'Lab 1 Tasks'
labels: ''
assignees: ''

---

Task list for lab:

- [ ] filled in name/student number in comment
- [ ] write factorial function
- [ ] write power function
- [ ] write fibonacci function
- [ ] analyze factorial function
- [ ] analyze power function
- [ ] analyze fibonacci function
- [ ] analyze the bubbleSort() function from lab specs
- [ ] complete successful pull request into main branch