---
name: Lab 5 Tasks
about: tasks related to lab 5
title: 'Lab 5 Tasks'
labels: ''
assignees: ''

---

Task list for lab:

- [ ] write the bracketCheck() function
- [ ] test and verify
- [ ] submit and commit pull request
