# Lab 0



## LaTex Formulas

Put your formulas here

hypotenus of a right angle triangle: $c = {\sqrt{a^2 + b^2}}$

geometric series: $\sum_{i=0}^{n}ar^i$

arithmetic series closed form: $\sum_{i = 1}^{n}(i)= {1 + 2 + 3 + 4...n={(n)(n+1)\over2}}$

## Graph

Put your graph here


![Picture1](https://user-images.githubusercontent.com/97711825/213074373-686a34d6-234c-475d-8b84-7daf2fd3df80.png)
